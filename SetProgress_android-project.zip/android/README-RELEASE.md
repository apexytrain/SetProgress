# SetProgress Android – Release signing

The Android project is configured for a production release signing key without storing any password in the project.

Required Gradle properties/environment variables:

- `SET_PROGRESS_KEYSTORE` – path to the `.jks` keystore
- `SET_PROGRESS_KEYSTORE_PASSWORD` – keystore password
- `SET_PROGRESS_KEY_ALIAS` – key alias
- `SET_PROGRESS_KEY_PASSWORD` – key password

Do **not** commit the keystore, passwords, or `gradle.properties` containing secrets to GitHub.

Once configured, the release AAB can be built with:

`./gradlew bundleRelease`
