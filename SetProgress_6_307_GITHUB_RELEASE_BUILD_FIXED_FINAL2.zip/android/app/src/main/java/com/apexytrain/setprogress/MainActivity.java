package com.apexytrain.setprogress;

import android.app.Activity;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.os.Build;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowInsets;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.ServiceWorkerClient;
import android.webkit.ServiceWorkerController;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;

public class MainActivity extends Activity {
    private WebView webView;
    private AudioManager audioManager;
    private AudioFocusRequest audioFocusRequest;

    @Override public void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(savedInstanceState);

        // Fullscreen muss VOR dem WebView-Layout gesetzt werden, damit Android
        // keinen Platz für Status-/Navigationsleiste reserviert.
        enableImmersiveMode();

        // Während SetProgress geöffnet ist, soll das Display beim Training nicht gesperrt werden.
        getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        webView = new WebView(this);
        webView.setFitsSystemWindows(false);
        setContentView(webView);
        enableImmersiveMode();
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        webView.addJavascriptInterface(new SetProgressNative(), "SetProgressNative");
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                enableImmersiveMode();
                webView.postDelayed(() -> enableImmersiveMode(), 250);
            }
        });
        if (android.os.Build.VERSION.SDK_INT >= 24) {
            ServiceWorkerController.getInstance().setServiceWorkerClient(new ServiceWorkerClient() {
                @Override public WebResourceResponse shouldInterceptRequest(WebResourceRequest request) { return null; }
            });
        }
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void enableImmersiveMode() {
        final android.view.View decor = getWindow().getDecorView();

        getWindow().setFlags(
                android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN
                        | android.view.WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN
                        | android.view.WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        );

        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
        }

        final int flags =
                android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | android.view.View.SYSTEM_UI_FLAG_FULLSCREEN
                | android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE;

        decor.setSystemUiVisibility(flags);

        if (Build.VERSION.SDK_INT >= 30) {
            android.view.WindowInsetsController controller = getWindow().getInsetsController();
            if (controller != null) {
                controller.setSystemBarsAppearance(0,
                        android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                                | android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS);
                controller.setSystemBarsBehavior(
                        android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                );
                controller.hide(
                        WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars()
                );
            }
        }
    }

    private void requestDuckingFocus() {
        if (audioManager == null) return;
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                if (audioFocusRequest == null) {
                    audioFocusRequest = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                            .setAudioAttributes(new AudioAttributes.Builder()
                                    .setUsage(AudioAttributes.USAGE_ALARM)
                                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                                    .build())
                            .setAcceptsDelayedFocusGain(false)
                            .build();
                }
                audioManager.requestAudioFocus(audioFocusRequest);
            } else {
                audioManager.requestAudioFocus(null, AudioManager.STREAM_ALARM, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK);
            }
        } catch (Exception ignored) {}
    }

    private void releaseDuckingFocus() {
        if (audioManager == null) return;
        try {
            if (Build.VERSION.SDK_INT >= 26 && audioFocusRequest != null) {
                audioManager.abandonAudioFocusRequest(audioFocusRequest);
            } else {
                audioManager.abandonAudioFocus(null);
            }
        } catch (Exception ignored) {}
    }

    private void playToneSequence(final String kind, final int profile) {
        new Thread(() -> {
            final int sampleRate = 48000;
            // Bewusst höher liegende, präsente Frequenzen: auf Smartphone-Lautsprechern
            // wirken sie deutlich klarer und lauter als tiefe Grundtöne.
            final float[][] warnProfiles = new float[][]{
                    {980},
                    {1320},
                    {1100, 1480},
                    {860, 1080},
                    {760, 1520},
                    {920, 1240}
            };
            final float[][] endProfiles = new float[][]{
                    {740, 1110, 1480},
                    {880, 1320, 1760},
                    {784, 1175, 1568},
                    {820, 1040, 1390},
                    {700, 1050, 1400, 1750},
                    {920, 1240, 1660}
            };
            int index = Math.max(1, Math.min(6, profile)) - 1;
            float[] freqs = "end".equals(kind) ? endProfiles[index] : warnProfiles[index];
            requestDuckingFocus();
            AudioTrack track = null;
            try {
                int toneMs = "warn".equals(kind) ? 180 : 330;
                int gapMs = "warn".equals(kind) ? 55 : 105;
                int totalMs = freqs.length * toneMs + Math.max(0, freqs.length - 1) * gapMs;
                int frames = sampleRate * totalMs / 1000;
                short[] data = new short[frames];
                int cursor = 0;
                for (float freq : freqs) {
                    int toneFrames = sampleRate * toneMs / 1000;
                    for (int i = 0; i < toneFrames && cursor < data.length; i++, cursor++) {
                        double attack = Math.min(1.0, i / (sampleRate * 0.012));
                        double release = Math.min(1.0, (toneFrames - i) / (sampleRate * 0.035));
                        double env = attack * release;
                        double phase = 2.0 * Math.PI * freq * i / sampleRate;
                        // Harmonische sorgen für einen modernen, präsenten Klang,
                        // ohne die Lautsprecher mit einem harten Rechtecksignal zu quälen.
                        double wave = 0.76 * Math.sin(phase)
                                + 0.17 * Math.sin(phase * 2.0)
                                + 0.07 * Math.sin(phase * 3.0);
                        if (profile == 5) wave = Math.tanh(wave * 1.55);
                        if (profile == 6) wave = 0.84 * wave + 0.16 * Math.sin(phase * 0.5);
                        data[cursor] = (short) (wave * env * ("warn".equals(kind) ? 0.98 : 1.0) * Short.MAX_VALUE);
                    }
                    int gapFrames = sampleRate * gapMs / 1000;
                    cursor = Math.min(data.length, cursor + gapFrames);
                }
                int min = AudioTrack.getMinBufferSize(sampleRate, android.media.AudioFormat.CHANNEL_OUT_MONO, android.media.AudioFormat.ENCODING_PCM_16BIT);
                track = new AudioTrack.Builder()
                        .setAudioAttributes(new AudioAttributes.Builder()
                                .setUsage(AudioAttributes.USAGE_ALARM)
                                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                                .build())
                        .setAudioFormat(new android.media.AudioFormat.Builder()
                                .setEncoding(android.media.AudioFormat.ENCODING_PCM_16BIT)
                                .setSampleRate(sampleRate)
                                .setChannelMask(android.media.AudioFormat.CHANNEL_OUT_MONO)
                                .build())
                        .setBufferSizeInBytes(Math.max(min, data.length * 2))
                        .setTransferMode(AudioTrack.MODE_STATIC)
                        .build();
                track.write(data, 0, data.length);
                track.setVolume(1.0f);
                track.play();
                Thread.sleep(totalMs + 80L);
            } catch (Exception ignored) {
            } finally {
                try { if (track != null) { track.stop(); track.release(); } } catch (Exception ignored) {}
                releaseDuckingFocus();
            }
        }).start();
    }

    private class SetProgressNative {
        @JavascriptInterface
        public void playRestTone(String kind, String profile) {
            int p = 1;
            try { p = Integer.parseInt(profile); } catch (Exception ignored) {}
            playToneSequence(kind, p);
        }


    }

    @Override protected void onResume() {
        super.onResume();
        enableImmersiveMode();
        if (webView != null) webView.postDelayed(() -> enableImmersiveMode(), 200);
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            enableImmersiveMode();
            if (webView != null) webView.postDelayed(() -> enableImmersiveMode(), 200);
        }
    }

    @Override protected void onDestroy() {
        super.onDestroy();
    }

    @Override protected void onPause() {
        // Android calls onPause() when the app is sent to the background,
        // including switching apps and leaving the activity. Persist the
        // current SetProgress workout immediately so it can be resumed
        // after the app is opened again.
        try {
            if (webView != null) {
                webView.evaluateJavascript(
                        "if(window.autoPauseWorkoutOnAppClose){window.autoPauseWorkoutOnAppClose();}",
                        null
                );
            }
        } catch (Exception ignored) {}
        super.onPause();
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
