package com.apexytrain.setprogress;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;
import android.webkit.ValueCallback;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.os.Build;
import android.os.Bundle;
import android.view.Window;
import android.view.View;
import android.view.WindowInsets;
import android.widget.FrameLayout;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.JsResult;
import android.app.AlertDialog;
import android.webkit.ServiceWorkerClient;
import android.webkit.ServiceWorkerController;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.os.ParcelFileDescriptor;
import java.io.OutputStream;
import java.io.InputStream;

public class MainActivity extends Activity {
    private WebView webView;
    private AudioManager audioManager;
    private AudioFocusRequest audioFocusRequest;
    private ValueCallback<Uri[]> filePathCallback;
    private String pendingBackupJson;
    private String pendingBackupFilename;
    private static final int REQUEST_OPEN_BACKUP = 4101;
    private static final int REQUEST_SAVE_BACKUP = 4102;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        showSystemBars();
        // Während SetProgress geöffnet ist, soll das Display beim Training nicht gesperrt werden.
        getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        webView = new WebView(this);
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsAlert(WebView view, String url, String message, final JsResult result) {
                // Eigene Android-Dialoge statt der WebView-Standardanzeige
                // "Auf der Seite file:// steht:". Dadurch sehen alle JS-Popups
                // innerhalb der App sauber aus und zeigen nur den eigentlichen Text.
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton("OK", (dialog, which) -> result.confirm())
                        .setOnCancelListener(dialog -> result.cancel())
                        .show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView view, String url, String message, final JsResult result) {
                // confirm() braucht eine echte synchrone Benutzerentscheidung,
                // deshalb wird hier ein nativer Dialog verwendet.
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setNegativeButton("ABBRECHEN", (dialog, which) -> result.cancel())
                        .setPositiveButton("OK", (dialog, which) -> result.confirm())
                        .setOnCancelListener(dialog -> result.cancel())
                        .show();
                return true;
            }

            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = callback;
                try {
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("application/json");
                    startActivityForResult(intent, REQUEST_OPEN_BACKUP);
                    return true;
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
            }
        });
        // Android 15/16 zeichnet Apps standardmäßig edge-to-edge.
        // SetProgress soll die Systemleisten aber außerhalb der App-Fläche halten.
        // Deshalb bekommt die App eine Root-Fläche, die den Status- und Navigationsbereich
        // per WindowInsets aus dem WebView-Bereich heraushält.
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(android.graphics.Color.rgb(9, 9, 15));
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(
                        WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars()
                );
                v.setPadding(0, bars.top, 0, bars.bottom);
            } else {
                v.setPadding(0, 0, 0, 0);
            }
            return insets;
        });
        root.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        ));
        setContentView(root);
        root.requestApplyInsets();
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        webView.addJavascriptInterface(new SetProgressNative(), "SetProgressNative");
        webView.setWebViewClient(new WebViewClient());
        if (android.os.Build.VERSION.SDK_INT >= 24) {
            ServiceWorkerController.getInstance().setServiceWorkerClient(new ServiceWorkerClient() {
                @Override public WebResourceResponse shouldInterceptRequest(WebResourceRequest request) { return null; }
            });
        }
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void showSystemBars() {
        final android.view.Window window = getWindow();
        final android.view.View decor = window.getDecorView();

        // Die Android-Systemleisten sollen innerhalb der App dauerhaft sichtbar sein.
        window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN);
        // Keine Immersive-API verwenden: Die Systemleisten bleiben sichtbar.
        decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
        if (Build.VERSION.SDK_INT >= 30) {
            // Unterstützt Geräte, auf denen das Betriebssystem die Insets nicht
            // automatisch an die Root-Ansicht weitergibt.
            window.setDecorFitsSystemWindows(true);
        }
        window.setStatusBarColor(android.graphics.Color.rgb(9, 9, 15));
        window.setNavigationBarColor(android.graphics.Color.rgb(9, 9, 15));
        if (Build.VERSION.SDK_INT >= 29) {
            window.setNavigationBarContrastEnforced(false);
            window.setStatusBarContrastEnforced(false);
        }
    }

    private void requestDuckingFocus() {
        if (audioManager == null) return;
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                if (audioFocusRequest == null) {
                    audioFocusRequest = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                            .setAudioAttributes(new AudioAttributes.Builder()
                                    .setUsage(AudioAttributes.USAGE_ALARM)
                                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                                    .build())
                            .setAcceptsDelayedFocusGain(false)
                            .build();
                }
                audioManager.requestAudioFocus(audioFocusRequest);
            } else {
                audioManager.requestAudioFocus(null, AudioManager.STREAM_ALARM, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK);
            }
        } catch (Exception ignored) {}
    }

    private void releaseDuckingFocus() {
        if (audioManager == null) return;
        try {
            if (Build.VERSION.SDK_INT >= 26 && audioFocusRequest != null) {
                audioManager.abandonAudioFocusRequest(audioFocusRequest);
            } else {
                audioManager.abandonAudioFocus(null);
            }
        } catch (Exception ignored) {}
    }

    private void playToneSequence(final String kind, final int profile) {
        new Thread(() -> {
            final int sampleRate = 48000;
            // Bewusst höher liegende, präsente Frequenzen: auf Smartphone-Lautsprechern
            // wirken sie deutlich klarer und lauter als tiefe Grundtöne.
            final float[][] warnProfiles = new float[][]{
                    {980},
                    {1320},
                    {1100, 1480},
                    {860, 1080},
                    {760, 1520},
                    {920, 1240}
            };
            final float[][] endProfiles = new float[][]{
                    {740, 1110, 1480},
                    {880, 1320, 1760},
                    {784, 1175, 1568},
                    {820, 1040, 1390},
                    {700, 1050, 1400, 1750},
                    {920, 1240, 1660}
            };
            int index = Math.max(1, Math.min(6, profile)) - 1;
            float[] freqs = "end".equals(kind) ? endProfiles[index] : warnProfiles[index];
            requestDuckingFocus();
            AudioTrack track = null;
            try {
                int toneMs = "warn".equals(kind) ? 180 : 330;
                int gapMs = "warn".equals(kind) ? 55 : 105;
                int totalMs = freqs.length * toneMs + Math.max(0, freqs.length - 1) * gapMs;
                int frames = sampleRate * totalMs / 1000;
                short[] data = new short[frames];
                int cursor = 0;
                for (float freq : freqs) {
                    int toneFrames = sampleRate * toneMs / 1000;
                    for (int i = 0; i < toneFrames && cursor < data.length; i++, cursor++) {
                        double attack = Math.min(1.0, i / (sampleRate * 0.012));
                        double release = Math.min(1.0, (toneFrames - i) / (sampleRate * 0.035));
                        double env = attack * release;
                        double phase = 2.0 * Math.PI * freq * i / sampleRate;
                        // Harmonische sorgen für einen modernen, präsenten Klang,
                        // ohne die Lautsprecher mit einem harten Rechtecksignal zu quälen.
                        double wave = 0.76 * Math.sin(phase)
                                + 0.17 * Math.sin(phase * 2.0)
                                + 0.07 * Math.sin(phase * 3.0);
                        if (profile == 5) wave = Math.tanh(wave * 1.55);
                        if (profile == 6) wave = 0.84 * wave + 0.16 * Math.sin(phase * 0.5);
                        data[cursor] = (short) (wave * env * ("warn".equals(kind) ? 0.98 : 1.0) * Short.MAX_VALUE);
                    }
                    int gapFrames = sampleRate * gapMs / 1000;
                    cursor = Math.min(data.length, cursor + gapFrames);
                }
                int min = AudioTrack.getMinBufferSize(sampleRate, android.media.AudioFormat.CHANNEL_OUT_MONO, android.media.AudioFormat.ENCODING_PCM_16BIT);
                track = new AudioTrack.Builder()
                        .setAudioAttributes(new AudioAttributes.Builder()
                                .setUsage(AudioAttributes.USAGE_ALARM)
                                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                                .build())
                        .setAudioFormat(new android.media.AudioFormat.Builder()
                                .setEncoding(android.media.AudioFormat.ENCODING_PCM_16BIT)
                                .setSampleRate(sampleRate)
                                .setChannelMask(android.media.AudioFormat.CHANNEL_OUT_MONO)
                                .build())
                        .setBufferSizeInBytes(Math.max(min, data.length * 2))
                        .setTransferMode(AudioTrack.MODE_STATIC)
                        .build();
                track.write(data, 0, data.length);
                track.setVolume(1.0f);
                track.play();
                Thread.sleep(totalMs + 80L);
            } catch (Exception ignored) {
            } finally {
                try { if (track != null) { track.stop(); track.release(); } } catch (Exception ignored) {}
                releaseDuckingFocus();
            }
        }).start();
    }

    private class SetProgressNative {
        @JavascriptInterface
        public void playRestTone(String kind, String profile) {
            int p = 1;
            try { p = Integer.parseInt(profile); } catch (Exception ignored) {}
            playToneSequence(kind, p);
        }

        @JavascriptInterface
        public void saveBackupFile(String json, String filename) {
            pendingBackupJson = json;
            pendingBackupFilename = (filename == null || filename.trim().isEmpty())
                    ? "setprogress-sicherung.json" : filename;
            try {
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE, pendingBackupFilename);
                startActivityForResult(intent, REQUEST_SAVE_BACKUP);
            } catch (Exception e) {
                pendingBackupJson = null;
                pendingBackupFilename = null;
                runOnUiThread(() -> webView.evaluateJavascript(
                        "if(window.toast){toast('Sicherung konnte nicht gespeichert werden');}", null));
            }
        }


    }

    @Override protected void onResume() {
        super.onResume();
        showSystemBars();
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) showSystemBars();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_OPEN_BACKUP) {
            if (filePathCallback != null) {
                Uri[] result = (resultCode == RESULT_OK && data != null && data.getData() != null)
                        ? new Uri[]{data.getData()} : null;
                filePathCallback.onReceiveValue(result);
                filePathCallback = null;
            }
            return;
        }

        if (requestCode == REQUEST_SAVE_BACKUP) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingBackupJson != null) {
                try {
                    Uri uri = data.getData();
                    try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                        if (out == null) throw new IllegalStateException("Datei konnte nicht geöffnet werden");
                        out.write(pendingBackupJson.getBytes(java.nio.charset.StandardCharsets.UTF_8));
                        out.flush();
                    }
                    if (webView != null) {
                        webView.post(() -> webView.evaluateJavascript(
                                "if(window.toast){toast('Sicherung gespeichert ✓');}", null));
                    }
                } catch (Exception e) {
                    if (webView != null) {
                        webView.post(() -> webView.evaluateJavascript(
                                "if(window.toast){toast('Sicherung konnte nicht gespeichert werden');}", null));
                    }
                }
            }
            pendingBackupJson = null;
            pendingBackupFilename = null;
        }
    }

    @Override protected void onDestroy() {
        super.onDestroy();
    }

    @Override protected void onPause() {
        // Android calls onPause() when the app is sent to the background,
        // including switching apps and leaving the activity. Persist the
        // current SetProgress workout immediately so it can be resumed
        // after the app is opened again.
        try {
            if (webView != null) {
                webView.evaluateJavascript(
                        "if(window.autoPauseWorkoutOnAppClose){window.autoPauseWorkoutOnAppClose();}",
                        null
                );
            }
        } catch (Exception ignored) {}
        super.onPause();
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
