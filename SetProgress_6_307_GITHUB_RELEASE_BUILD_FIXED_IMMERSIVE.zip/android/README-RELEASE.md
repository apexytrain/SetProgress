# SetProgress – Release Build

## GitHub Actions

The workflow at `.github/workflows/android-release.yml` builds the release AAB with Gradle 8.7 and Java 17.

It runs manually (`workflow_dispatch`) or when a tag starting with `v` is pushed.

### Signing

The Android project already supports release signing through these environment variables:

- `SET_PROGRESS_KEYSTORE`
- `SET_PROGRESS_KEYSTORE_PASSWORD`
- `SET_PROGRESS_KEY_ALIAS`
- `SET_PROGRESS_KEY_PASSWORD`

For a signed Google Play AAB, add the corresponding GitHub Actions secrets and make the keystore available to the workflow at `android/app/release-key.jks` (for example, by adding a separate secure step to decode a base64-encoded keystore secret). **Do not commit the keystore or passwords to GitHub.**

Without a keystore, the workflow still verifies the Gradle release configuration, but the resulting AAB must not be used as the final Google Play upload until it is properly signed.

## Current app version

- versionName: `6.307`
- versionCode: `23`
- targetSdk: `35`
