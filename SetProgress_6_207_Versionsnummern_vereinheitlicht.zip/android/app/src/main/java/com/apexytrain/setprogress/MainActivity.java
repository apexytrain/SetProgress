package com.apexytrain.setprogress;

import android.app.Activity;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.os.Build;
import android.os.Bundle;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.ServiceWorkerClient;
import android.webkit.ServiceWorkerController;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;

public class MainActivity extends Activity {
    private WebView webView;
    private AudioManager audioManager;
    private AudioFocusRequest audioFocusRequest;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        // Während SetProgress geöffnet ist, soll das Display beim Training nicht gesperrt werden.
        getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        webView.addJavascriptInterface(new SetProgressNative(), "SetProgressNative");
        webView.setWebViewClient(new WebViewClient());
        if (android.os.Build.VERSION.SDK_INT >= 24) {
            ServiceWorkerController.getInstance().setServiceWorkerClient(new ServiceWorkerClient() {
                @Override public WebResourceResponse shouldInterceptRequest(WebResourceRequest request) { return null; }
            });
        }
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void requestDuckingFocus() {
        if (audioManager == null) return;
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                if (audioFocusRequest == null) {
                    audioFocusRequest = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                            .setAudioAttributes(new AudioAttributes.Builder()
                                    .setUsage(AudioAttributes.USAGE_ALARM)
                                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                                    .build())
                            .setAcceptsDelayedFocusGain(false)
                            .build();
                }
                audioManager.requestAudioFocus(audioFocusRequest);
            } else {
                audioManager.requestAudioFocus(null, AudioManager.STREAM_ALARM, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK);
            }
        } catch (Exception ignored) {}
    }

    private void releaseDuckingFocus() {
        if (audioManager == null) return;
        try {
            if (Build.VERSION.SDK_INT >= 26 && audioFocusRequest != null) {
                audioManager.abandonAudioFocusRequest(audioFocusRequest);
            } else {
                audioManager.abandonAudioFocus(null);
            }
        } catch (Exception ignored) {}
    }

    private void playToneSequence(final String kind, final int profile) {
        new Thread(() -> {
            final int sampleRate = 48000;
            final float[][] profiles = new float[][]{
                    {660}, {880}, {740, 740}, {520, 620}, {980}, {600, 800}
            };
            int index = Math.max(1, Math.min(6, profile)) - 1;
            float[] freqs = profiles[index];
            if ("end".equals(kind)) {
                if (profile == 1) freqs = new float[]{520, 780};
                else if (profile == 2) freqs = new float[]{440, 880};
                else if (profile == 3) freqs = new float[]{660, 990};
                else if (profile == 4) freqs = new float[]{520, 1040, 520};
                else if (profile == 5) freqs = new float[]{880, 660, 1040};
                else freqs = new float[]{740, 740, 1100};
            }
            requestDuckingFocus();
            AudioTrack track = null;
            try {
                int toneMs = "warn".equals(kind) ? 180 : 260;
                int gapMs = "warn".equals(kind) ? 90 : 170;
                int totalMs = freqs.length * toneMs + Math.max(0, freqs.length - 1) * gapMs;
                int frames = sampleRate * totalMs / 1000;
                short[] data = new short[frames];
                int cursor = 0;
                for (float freq : freqs) {
                    int toneFrames = sampleRate * toneMs / 1000;
                    for (int i = 0; i < toneFrames && cursor < data.length; i++, cursor++) {
                        double env = Math.min(1.0, i / (sampleRate * 0.015));
                        env *= Math.min(1.0, (toneFrames - i) / (sampleRate * 0.025));
                        double wave = Math.sin(2.0 * Math.PI * freq * i / sampleRate);
                        data[cursor] = (short) (wave * env * 0.92 * Short.MAX_VALUE);
                    }
                    int gapFrames = sampleRate * gapMs / 1000;
                    cursor = Math.min(data.length, cursor + gapFrames);
                }
                int min = AudioTrack.getMinBufferSize(sampleRate, android.media.AudioFormat.CHANNEL_OUT_MONO, android.media.AudioFormat.ENCODING_PCM_16BIT);
                track = new AudioTrack.Builder()
                        .setAudioAttributes(new AudioAttributes.Builder()
                                .setUsage(AudioAttributes.USAGE_ALARM)
                                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                                .build())
                        .setAudioFormat(new android.media.AudioFormat.Builder()
                                .setEncoding(android.media.AudioFormat.ENCODING_PCM_16BIT)
                                .setSampleRate(sampleRate)
                                .setChannelMask(android.media.AudioFormat.CHANNEL_OUT_MONO)
                                .build())
                        .setBufferSizeInBytes(Math.max(min, data.length * 2))
                        .setTransferMode(AudioTrack.MODE_STATIC)
                        .build();
                track.write(data, 0, data.length);
                track.setVolume(1.0f);
                track.play();
                Thread.sleep(totalMs + 80L);
            } catch (Exception ignored) {
            } finally {
                try { if (track != null) { track.stop(); track.release(); } } catch (Exception ignored) {}
                releaseDuckingFocus();
            }
        }).start();
    }

    private class SetProgressNative {
        @JavascriptInterface
        public void playRestTone(String kind, String profile) {
            int p = 1;
            try { p = Integer.parseInt(profile); } catch (Exception ignored) {}
            playToneSequence(kind, p);
        }
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
