package com.apexytrain.setprogress;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;
import android.webkit.ValueCallback;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.os.Build;
import android.os.Bundle;
import android.view.Window;
import android.view.View;
import android.view.WindowInsets;
import android.widget.FrameLayout;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.JsResult;
import android.app.AlertDialog;
import android.webkit.ServiceWorkerClient;
import android.webkit.ServiceWorkerController;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.os.ParcelFileDescriptor;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Button;
import java.io.OutputStream;
import java.io.InputStream;

public class MainActivity extends Activity {
    private WebView webView;
    private AudioManager audioManager;
    private AudioFocusRequest audioFocusRequest;
    private ValueCallback<Uri[]> filePathCallback;
    private String pendingBackupJson;
    private String pendingBackupFilename;
    private static final int REQUEST_OPEN_BACKUP = 4101;
    private static final int REQUEST_SAVE_BACKUP = 4102;
    private static final long TRIAL_DURATION_MS = 14L * 24L * 60L * 60L * 1000L;
    private static final String TRIAL_PREFS = "setprogress_trial";
    private static final String TRIAL_START = "trial_start_ms";
    private FrameLayout root;
    private View trialLockOverlay;
    private TextView trialBanner;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        showSystemBars();
        // Während SetProgress geöffnet ist, soll das Display beim Training nicht gesperrt werden.
        getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        webView = new WebView(this);
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsAlert(WebView view, String url, String message, final JsResult result) {
                // Eigene Android-Dialoge statt der WebView-Standardanzeige
                // "Auf der Seite file:// steht:". Dadurch sehen alle JS-Popups
                // innerhalb der App sauber aus und zeigen nur den eigentlichen Text.
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton("OK", (dialog, which) -> result.confirm())
                        .setOnCancelListener(dialog -> result.cancel())
                        .show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView view, String url, String message, final JsResult result) {
                // confirm() braucht eine echte synchrone Benutzerentscheidung,
                // deshalb wird hier ein nativer Dialog verwendet.
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setNegativeButton("ABBRECHEN", (dialog, which) -> result.cancel())
                        .setPositiveButton("OK", (dialog, which) -> result.confirm())
                        .setOnCancelListener(dialog -> result.cancel())
                        .show();
                return true;
            }

            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = callback;
                try {
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("application/json");
                    startActivityForResult(intent, REQUEST_OPEN_BACKUP);
                    return true;
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
            }
        });
        // Die Android-Systemleisten sollen außerhalb der WebView-Inhaltsfläche liegen.
        // Die App nutzt targetSdk 35, damit Android 16 die Edge-to-Edge-Erzwingung für
        // targetSdk 36 nicht aktiviert; zusätzlich werden die Insets sauber berücksichtigt.
        root = new FrameLayout(this);
        root.setBackgroundColor(android.graphics.Color.rgb(9, 9, 15));
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(
                        WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars()
                );
                v.setPadding(0, bars.top, 0, bars.bottom);
            } else {
                v.setPadding(0, 0, 0, 0);
            }
            return insets;
        });
        FrameLayout.LayoutParams webParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        );
        webParams.topMargin = dp(44);
        root.addView(webView, webParams);
        trialBanner = new TextView(this);
        trialBanner.setGravity(Gravity.CENTER);
        trialBanner.setTextColor(Color.WHITE);
        trialBanner.setTextSize(13);
        trialBanner.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        trialBanner.setBackgroundColor(Color.rgb(70, 42, 105));
        trialBanner.setPadding(dp(12), 0, dp(12), 0);
        FrameLayout.LayoutParams bannerParams = new FrameLayout.LayoutParams(-1, dp(44));
        bannerParams.gravity = Gravity.TOP;
        root.addView(trialBanner, bannerParams);
        setContentView(root);
        root.requestApplyInsets();
        initializeTrial();
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        webView.addJavascriptInterface(new SetProgressNative(), "SetProgressNative");
        webView.setWebViewClient(new WebViewClient());
        if (android.os.Build.VERSION.SDK_INT >= 24) {
            ServiceWorkerController.getInstance().setServiceWorkerClient(new ServiceWorkerClient() {
                @Override public WebResourceResponse shouldInterceptRequest(WebResourceRequest request) { return null; }
            });
        }
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void initializeTrial() {
        SharedPreferences prefs = getSharedPreferences(TRIAL_PREFS, MODE_PRIVATE);
        long start = prefs.getLong(TRIAL_START, 0L);
        if (start <= 0L) {
            start = System.currentTimeMillis();
            prefs.edit().putLong(TRIAL_START, start).apply();
            android.widget.Toast.makeText(this, "SetProgress Testversion · 14 Tage kostenlos", android.widget.Toast.LENGTH_LONG).show();
        }
        updateTrialGate(start);
    }

    private void updateTrialGate(long start) {
        long elapsed = System.currentTimeMillis() - start;
        if (elapsed >= TRIAL_DURATION_MS) {
            showTrialExpiredOverlay();
        } else {
        }
        if (elapsed < TRIAL_DURATION_MS && trialLockOverlay != null) {
            root.removeView(trialLockOverlay);
            trialLockOverlay = null;
        }
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void showTrialExpiredOverlay() {
        if (trialLockOverlay != null) return;

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setPadding(32, 32, 32, 32);
        box.setBackgroundColor(Color.rgb(9, 9, 15));

        TextView icon = new TextView(this);
        icon.setText("⏳");
        icon.setTextSize(42);
        icon.setGravity(Gravity.CENTER);

        TextView title = new TextView(this);
        title.setText("Testphase beendet");
        title.setTextColor(Color.WHITE);
        title.setTextSize(27);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 18, 0, 8);

        TextView message = new TextView(this);
        message.setText("Die 14-tägige Testphase von SetProgress ist abgelaufen. Vielen Dank fürs Testen!\n\nFür die spätere Vollversion wird SetProgress über Google Play freigeschaltet.");
        message.setTextColor(Color.rgb(170, 178, 195));
        message.setTextSize(15);
        message.setGravity(Gravity.CENTER);
        message.setLineSpacing(0f, 1.2f);

        Button close = new Button(this);
        close.setText("SetProgress schließen");
        close.setTextColor(Color.WHITE);
        close.setAllCaps(false);
        close.setTextSize(15);
        close.setOnClickListener(v -> finishAffinity());

        LinearLayout.LayoutParams textParams = new LinearLayout.LayoutParams(-1, -2);
        LinearLayout.LayoutParams buttonParams = new LinearLayout.LayoutParams(-1, -2);
        buttonParams.topMargin = 28;
        box.addView(icon, new LinearLayout.LayoutParams(-1, -2));
        box.addView(title, textParams);
        box.addView(message, textParams);
        box.addView(close, buttonParams);

        FrameLayout.LayoutParams overlayParams = new FrameLayout.LayoutParams(-1, -1);
        overlayParams.gravity = Gravity.CENTER;
        trialLockOverlay = box;
        root.addView(trialLockOverlay, overlayParams);
        trialLockOverlay.bringToFront();
    }

    private void showSystemBars() {
        final android.view.Window window = getWindow();
        final android.view.View decor = window.getDecorView();

        // Die Android-Systemleisten sollen innerhalb der App dauerhaft sichtbar sein.
        window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN);
        // Keine Immersive-API verwenden: Die Systemleisten bleiben sichtbar.
        decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
        if (Build.VERSION.SDK_INT >= 30) {
            // Unterstützt Geräte, auf denen das Betriebssystem die Insets nicht
            // automatisch an die Root-Ansicht weitergibt.
            window.setDecorFitsSystemWindows(true);
        }
        window.setStatusBarColor(android.graphics.Color.rgb(9, 9, 15));
        window.setNavigationBarColor(android.graphics.Color.rgb(9, 9, 15));
        if (Build.VERSION.SDK_INT >= 29) {
            window.setNavigationBarContrastEnforced(false);
            window.setStatusBarContrastEnforced(false);
        }
    }

    private void requestDuckingFocus() {
        if (audioManager == null) return;
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                if (audioFocusRequest == null) {
                    audioFocusRequest = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                            .setAudioAttributes(new AudioAttributes.Builder()
                                    .setUsage(AudioAttributes.USAGE_ALARM)
                                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                                    .build())
                            .setAcceptsDelayedFocusGain(false)
                            .build();
                }
                audioManager.requestAudioFocus(audioFocusRequest);
            } else {
                audioManager.requestAudioFocus(null, AudioManager.STREAM_ALARM, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK);
            }
        } catch (Exception ignored) {}
    }

    private void releaseDuckingFocus() {
        if (audioManager == null) return;
        try {
            if (Build.VERSION.SDK_INT >= 26 && audioFocusRequest != null) {
                audioManager.abandonAudioFocusRequest(audioFocusRequest);
            } else {
                audioManager.abandonAudioFocus(null);
            }
        } catch (Exception ignored) {}
    }

    private void playToneSequence(final String kind, final int profile) {
        new Thread(() -> {
            final int sampleRate = 48000;
            // Bewusst höher liegende, präsente Frequenzen: auf Smartphone-Lautsprechern
            // wirken sie deutlich klarer und lauter als tiefe Grundtöne.
            final float[][] warnProfiles = new float[][]{
                    {980},
                    {1320},
                    {1100, 1480},
                    {860, 1080},
                    {760, 1520},
                    {920, 1240}
            };
            final float[][] endProfiles = new float[][]{
                    {740, 1110, 1480},
                    {880, 1320, 1760},
                    {784, 1175, 1568},
                    {820, 1040, 1390},
                    {700, 1050, 1400, 1750},
                    {920, 1240, 1660}
            };
            int index = Math.max(1, Math.min(6, profile)) - 1;
            float[] freqs = "end".equals(kind) ? endProfiles[index] : warnProfiles[index];
            requestDuckingFocus();
            AudioTrack track = null;
            try {
                int toneMs = "warn".equals(kind) ? 180 : 330;
                int gapMs = "warn".equals(kind) ? 55 : 105;
                int totalMs = freqs.length * toneMs + Math.max(0, freqs.length - 1) * gapMs;
                int frames = sampleRate * totalMs / 1000;
                short[] data = new short[frames];
                int cursor = 0;
                for (float freq : freqs) {
                    int toneFrames = sampleRate * toneMs / 1000;
                    for (int i = 0; i < toneFrames && cursor < data.length; i++, cursor++) {
                        double attack = Math.min(1.0, i / (sampleRate * 0.012));
                        double release = Math.min(1.0, (toneFrames - i) / (sampleRate * 0.035));
                        double env = attack * release;
                        double phase = 2.0 * Math.PI * freq * i / sampleRate;
                        // Harmonische sorgen für einen modernen, präsenten Klang,
                        // ohne die Lautsprecher mit einem harten Rechtecksignal zu quälen.
                        double wave = 0.76 * Math.sin(phase)
                                + 0.17 * Math.sin(phase * 2.0)
                                + 0.07 * Math.sin(phase * 3.0);
                        if (profile == 5) wave = Math.tanh(wave * 1.55);
                        if (profile == 6) wave = 0.84 * wave + 0.16 * Math.sin(phase * 0.5);
                        data[cursor] = (short) (wave * env * ("warn".equals(kind) ? 0.98 : 1.0) * Short.MAX_VALUE);
                    }
                    int gapFrames = sampleRate * gapMs / 1000;
                    cursor = Math.min(data.length, cursor + gapFrames);
                }
                int min = AudioTrack.getMinBufferSize(sampleRate, android.media.AudioFormat.CHANNEL_OUT_MONO, android.media.AudioFormat.ENCODING_PCM_16BIT);
                track = new AudioTrack.Builder()
                        .setAudioAttributes(new AudioAttributes.Builder()
                                .setUsage(AudioAttributes.USAGE_ALARM)
                                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                                .build())
                        .setAudioFormat(new android.media.AudioFormat.Builder()
                                .setEncoding(android.media.AudioFormat.ENCODING_PCM_16BIT)
                                .setSampleRate(sampleRate)
                                .setChannelMask(android.media.AudioFormat.CHANNEL_OUT_MONO)
                                .build())
                        .setBufferSizeInBytes(Math.max(min, data.length * 2))
                        .setTransferMode(AudioTrack.MODE_STATIC)
                        .build();
                track.write(data, 0, data.length);
                track.setVolume(1.0f);
                track.play();
                Thread.sleep(totalMs + 80L);
            } catch (Exception ignored) {
            } finally {
                try { if (track != null) { track.stop(); track.release(); } } catch (Exception ignored) {}
                releaseDuckingFocus();
            }
        }).start();
    }

    private class SetProgressNative {
        @JavascriptInterface
        public void playRestTone(String kind, String profile) {
            int p = 1;
            try { p = Integer.parseInt(profile); } catch (Exception ignored) {}
            playToneSequence(kind, p);
        }

        @JavascriptInterface
        public void saveBackupFile(String json, String filename) {
            pendingBackupJson = json;
            pendingBackupFilename = (filename == null || filename.trim().isEmpty())
                    ? "setprogress-sicherung.json" : filename;
            try {
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE, pendingBackupFilename);
                startActivityForResult(intent, REQUEST_SAVE_BACKUP);
            } catch (Exception e) {
                pendingBackupJson = null;
                pendingBackupFilename = null;
                runOnUiThread(() -> webView.evaluateJavascript(
                        "if(window.toast){toast('Sicherung konnte nicht gespeichert werden');}", null));
            }
        }


    }

    @Override protected void onResume() {
        super.onResume();
        showSystemBars();
        if (root != null) {
            SharedPreferences prefs = getSharedPreferences(TRIAL_PREFS, MODE_PRIVATE);
            long start = prefs.getLong(TRIAL_START, 0L);
            if (start > 0L) updateTrialGate(start);
        }
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) showSystemBars();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_OPEN_BACKUP) {
            if (filePathCallback != null) {
                Uri[] result = (resultCode == RESULT_OK && data != null && data.getData() != null)
                        ? new Uri[]{data.getData()} : null;
                filePathCallback.onReceiveValue(result);
                filePathCallback = null;
            }
            return;
        }

        if (requestCode == REQUEST_SAVE_BACKUP) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingBackupJson != null) {
                try {
                    Uri uri = data.getData();
                    try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                        if (out == null) throw new IllegalStateException("Datei konnte nicht geöffnet werden");
                        out.write(pendingBackupJson.getBytes(java.nio.charset.StandardCharsets.UTF_8));
                        out.flush();
                    }
                    if (webView != null) {
                        webView.post(() -> webView.evaluateJavascript(
                                "if(window.toast){toast('Sicherung gespeichert ✓');}", null));
                    }
                } catch (Exception e) {
                    if (webView != null) {
                        webView.post(() -> webView.evaluateJavascript(
                                "if(window.toast){toast('Sicherung konnte nicht gespeichert werden');}", null));
                    }
                }
            }
            pendingBackupJson = null;
            pendingBackupFilename = null;
        }
    }

    @Override protected void onDestroy() {
        super.onDestroy();
    }

    @Override protected void onPause() {
        // Android calls onPause() when the app is sent to the background,
        // including switching apps and leaving the activity. Persist the
        // current SetProgress workout immediately so it can be resumed
        // after the app is opened again.
        try {
            if (webView != null) {
                webView.evaluateJavascript(
                        "if(window.autoPauseWorkoutOnAppClose){window.autoPauseWorkoutOnAppClose();}",
                        null
                );
            }
        } catch (Exception ignored) {}
        super.onPause();
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
